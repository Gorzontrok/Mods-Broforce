# Instructions

To rename a bro, got to it's line and add an name between the two `"` after the `:`

Example:
```json
{
    "Rambro": "I must shoot",
    [...]
}