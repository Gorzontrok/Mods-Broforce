-- Instruction :
 - For add a Custom name to a bro, open 'CustomHeroName.txt', go to the bro you want to change the name.
 - After finding the bro add a space and the name after his basic name. You can add a sentence if you want.
 	Example :
		Rambro PiouPiou
		Brommando I like rocket